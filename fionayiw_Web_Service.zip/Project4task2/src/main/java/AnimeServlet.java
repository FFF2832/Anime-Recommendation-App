/**
 * Author: Fiona Yi Ting Wang (fionayiw)
 * Email: fionayiw@andrew.cmu.edu
 * Date: April 6, 2026
 * Course: 95702 Distributed Systems Project 4 Task 2
 * Description: This web service provides a random anime discovery feature by
 * interacting with the Jikan API. It filters results based on user preferences,
 * processes metadata for logging into MongoDB Atlas, and returns a lean JSON
 * response to the Android client.
 */



import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.Date;
import java.util.Random;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import org.json.JSONObject;
import org.json.JSONArray;

@WebServlet(name = "AnimeServlet", value = "/getAnime")
public class AnimeServlet extends HttpServlet {

    /* MongoDB Atlas connection string verified during Task 1 implementation */
    private final String mongoUri = "mongodb+srv://fionaw32:fionayiw@fionaw.me59boo.mongodb.net/?appName=FionaW";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        /* Initialize timing for performance tracking and capture device metadata */
        long startTime = System.currentTimeMillis();
        String userAgent = request.getHeader("User-Agent");
        String clientIP = request.getRemoteAddr();

        /* Retrieve user-defined filters from the mobile application parameters */
        String genreId = request.getParameter("genre");
        String minScore = request.getParameter("score");

        /* Apply default values if the mobile app did not provide specific search criteria */
        if (genreId == null) genreId = "1";
        if (minScore == null) minScore = "8.0";

        /* Construct a RESTful request to the Jikan API with specific search and sorting parameters */
        String searchUrl = "https://api.jikan.moe/v4/anime?genres=" + genreId + "&min_score=" + minScore + "&order_by=score&sort=desc";
        URL url = new URL(searchUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        int responseCode = conn.getResponseCode();
        StringBuilder rawResponse = new StringBuilder();

        /* Stream the API response into a string builder for JSON processing */
        if (responseCode == 200) {
            try (Scanner scanner = new Scanner(conn.getInputStream())) {
                while (scanner.hasNext()) {
                    rawResponse.append(scanner.nextLine());
                }
            }
        }

        /* Execute business logic by picking a random anime from the top search results to provide a discovery experience */
        JSONObject jobj = new JSONObject(rawResponse.toString());
        JSONArray animeList = jobj.getJSONArray("data");
        JSONObject filteredResponse = new JSONObject();

        if (animeList.length() > 0) {
            /* Select a random entry to ensure a diverse user experience with every request */
            int randomIndex = new Random().nextInt(animeList.length());
            JSONObject picked = animeList.getJSONObject(randomIndex);

            /* Filter out unnecessary metadata to minimize network latency and mobile processing load */
            filteredResponse.put("title", picked.getString("title"));
            filteredResponse.put("score", picked.getDouble("score"));
            filteredResponse.put("image_url", picked.getJSONObject("images").getJSONObject("jpg").getString("large_image_url"));
            filteredResponse.put("synopsis", picked.optString("synopsis", "No description available."));
        }

        /* Persist operational logs to the cloud database for dashboard reporting and analysis */
        try (MongoClient mongoClient = MongoClients.create(mongoUri)) {
            MongoDatabase database = mongoClient.getDatabase("project4");
            MongoCollection<Document> collection = database.getCollection("logs");

            /* Construct a document containing at least six pieces of distinct operational information */
            Document logEntry = new Document()
                    .append("timestamp", new Date())
                    .append("deviceInfo", userAgent)
                    .append("remoteAddress", clientIP)
                    .append("genreSelected", genreId)
                    .append("httpStatus", responseCode)
                    .append("processingLatency", System.currentTimeMillis() - startTime);

            collection.insertOne(logEntry);
        } catch (Exception e) {
            System.err.println("Database operations failed: " + e.getMessage());
        }

        /* Transmit the final filtered JSON object back to the Android client with appropriate encoding */
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(filteredResponse.toString());
        out.flush();
    }
}