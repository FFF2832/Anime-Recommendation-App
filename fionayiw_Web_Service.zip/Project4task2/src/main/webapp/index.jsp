<%--
 * Author: Fiona Yi Ting Wang (fionayiw)
 * Email: fionayiw@andrew.cmu.edu
 * Date: April 8, 2026
 * Course: 95702 Distributed Systems Project 4 Task 2
 * Description: This web service provides a random anime discovery feature by
 * interacting with the Jikan API. It filters results based on user preferences,
 * processes metadata for logging into MongoDB Atlas, and returns a lean JSON
 * response to the Android client. This dashboard serves as the operations
 * interface for viewing analytics and logs.
--%>
<%@ page import="com.mongodb.client.*" %>
<%@ page import="org.bson.Document" %>
<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Anime Service Analytics Dashboard</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 40px; color: #333; background-color: #fcfcfc; }
        /* Analytics Card Layout */
        .analytics-container { display: flex; gap: 20px; margin-bottom: 40px; }
        .card {
            padding: 20px; border: 1px solid #e0e0e0; border-radius: 12px;
            background: #ffffff; flex: 1; text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .card h3 { margin: 0; font-size: 14px; color: #777; text-transform: uppercase; letter-spacing: 1px; }
        .card p { font-size: 26px; font-weight: bold; margin: 10px 0; color: #2E7D32; }

        /* Table Styling  */
        table { border-collapse: collapse; width: 100%; margin-top: 20px; background: white; border-radius: 8px; overflow: hidden; }
        th, td { border: 1px solid #eee; padding: 14px; text-align: left; }
        th { background-color: #4CAF50; color: white; font-weight: 600; }
        tr:nth-child(even) { background-color: #fdfdfd; }
        tr:hover { background-color: #f5f5f5; }
        h1 { color: #1B5E20; margin-bottom: 5px; }
        .sub-header { color: #666; margin-bottom: 30px; }
    </style>
</head>
<body>
<h1>Service Operations Dashboard</h1>
<p class="sub-header">Real-time analytics and detailed interaction logs for Fiona's Anime Recommender.</p>

<%
    // Connection string for MongoDB Atlas
    String uri = "mongodb+srv://fionaw32:fionayiw@fionaw.me59boo.mongodb.net/?appName=FionaW";

    List<Document> allLogs = new ArrayList<>();
    double totalLatency = 0;
    Map<Object, Integer> genreFrequency = new HashMap<>();

    try (MongoClient mongoClient = MongoClients.create(uri)) {
        MongoDatabase database = mongoClient.getDatabase("project4");
        MongoCollection<Document> collection = database.getCollection("logs");

        // Fetch logs sorted by timestamp
        for (Document doc : collection.find().sort(new Document("timestamp", -1))) {
            allLogs.add(doc);

            // Analytics: Aggregate Latency
            Object latencyObj = doc.get("processingLatency");
            if (latencyObj != null) {
                try {
                    totalLatency += Double.parseDouble(latencyObj.toString());
                } catch(Exception e) {}
            }

            // Analytics: Aggregate Genre Frequency
            Object genreObj = doc.get("genreSelected");
            if (genreObj != null) {
                genreFrequency.put(genreObj, genreFrequency.getOrDefault(genreObj, 0) + 1);
            }
        }
    } catch (Exception e) {
        out.println("<div style='color:red;'>Database Connection Error: " + e.getMessage() + "</div>");
    }

    // Calculate Final Metrics
    int totalRequests = allLogs.size();
    double avgLatency = totalRequests > 0 ? totalLatency / totalRequests : 0;

    // Find top Genre ID and map to Name
    Object topId = "N/A";
    int max = 0;
    for (Map.Entry<Object, Integer> entry : genreFrequency.entrySet()) {
        if (entry.getValue() > max) {
            max = entry.getValue();
            topId = entry.getKey();
        }
    }

    // ID to Name Mapping Table
    Map<String, String> idToName = new HashMap<>();
    idToName.put("1", "Action"); idToName.put("4", "Comedy"); idToName.put("7", "Mystery");
    idToName.put("10", "Fantasy"); idToName.put("22", "Romance"); idToName.put("24", "Sci-Fi");
    idToName.put("62", "Isekai"); idToName.put("30", "Sports"); idToName.put("2", "Adventure");
    idToName.put("41", "Suspense");

    String topGenreName = idToName.getOrDefault(String.valueOf(topId), String.valueOf(topId));
%>

<div class="analytics-container">
    <div class="card">
        <h3>Total Traffic</h3>
        <p><%= totalRequests %> <span style="font-size: 14px; color: #999;">reqs</span></p>
    </div>
    <div class="card">
        <h3>Avg Performance</h3>
        <p><%= String.format("%.2f", avgLatency) %> <span style="font-size: 14px;">ms</span></p>
    </div>
    <div class="card">
        <h3>Top Category</h3>
        <p><%= topGenreName %></p>
    </div>
</div>

<h2>Detailed Interaction Logs</h2>
<table>
    <thead>
    <tr>
        <th>Timestamp (UTC)</th>
        <th>Device Model</th>
        <th>Client IP</th>
        <th>Genre ID</th>
        <th>API Status</th>
        <th>Latency (ms)</th>
    </tr>
    </thead>
    <tbody>
    <% for (Document doc : allLogs) { %>
    <tr>
        <td><%= doc.get("timestamp") %></td>
        <td><%= doc.getString("deviceInfo") %></td>
        <td><%= doc.getString("remoteAddress") %></td>
        <td><%= doc.get("genreSelected") %></td>
        <td><%= doc.get("httpStatus") %></td>
        <td><%= doc.get("processingLatency") %></td>
    </tr>
    <% } %>
    </tbody>
</table>
</body>
</html>