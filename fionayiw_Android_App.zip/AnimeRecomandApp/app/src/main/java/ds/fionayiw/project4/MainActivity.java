package ds.fionayiw.project4;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Author: Fiona Yi Ting Wang (fionayiw)
 * Course: 95702 Distributed Systems Project 4
 * Description: An Android client that fetches anime recommendations based on
 * user-selected genre and minimum score. It communicates with a remote Servlet
 * and handles JSON parsing, multi-threading, and asynchronous image loading.
 */
public class MainActivity extends AppCompatActivity {

    // The deployed Servlet endpoint on GitHub Codespaces
    private final String API_URL = "https://didactic-capybara-94x97q5jj96c79vq-8080.app.github.dev/getAnime";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Link with activity_main.xml layout
        setContentView(R.layout.activity_main);

        // Initialize UI components
        Spinner spinnerGenre = findViewById(R.id.spinnerGenre);
        EditText editScore = findViewById(R.id.editScore);
        Button btnSearch = findViewById(R.id.btnSearch);
        TextView txtTitle = findViewById(R.id.txtTitle);
        TextView txtSynopsis = findViewById(R.id.txtSynopsis);
        ImageView imgAnime = findViewById(R.id.imgAnime);

        // Define the search button behavior
        btnSearch.setOnClickListener(v -> {

            /* Mapping the Spinner selection index to MyAnimeList Genre IDs.
             * Order: Action(1), Comedy(4), Mystery(7), Fantasy(10), Romance(22),
             * Sci-Fi(24), Isekai(62), Sports(30), Adventure(2), Suspense(41)
             */
            int[] genreIds = {1, 4, 7, 10, 22, 24, 62, 30, 2, 41};

            // Retrieve user selections from UI
            int selectedIndex = spinnerGenre.getSelectedItemPosition();
            int genreId = genreIds[selectedIndex];
            String score = editScore.getText().toString();

            // Client-side validation for the score input
            if (score.isEmpty()) {
                Toast.makeText(this, "Please enter a minimum score", Toast.LENGTH_SHORT).show();
                return;
            }

            // Network operations must run on a background thread to avoid blocking the UI
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    // Construct the URL with multiple dynamic query parameters
                    URL url = new URL(API_URL + "?genre=" + genreId + "&score=" + score);

                    // Open HTTP connection and configure the request
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    // Set custom User-Agent for server-side logging (stored in MongoDB)
                    conn.setRequestProperty("User-Agent", "Fiona-Android-App-Project4");

                    // Check for HTTP OK response (200)
                    if (conn.getResponseCode() == 200) {
                        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder resp = new StringBuilder();
                        String line;
                        while ((line = in.readLine()) != null) {
                            resp.append(line);
                        }

                        // Parse the raw JSON string returned by the Servlet
                        JSONObject json = new JSONObject(resp.toString());
                        String title = json.getString("title");
                        String imageUrl = json.getString("image_url");
                        String synopsis = json.getString("synopsis");

                        // Update UI elements back on the Main UI Thread
                        runOnUiThread(() -> {
                            txtTitle.setText("Recommended: " + title);
                            txtSynopsis.setText("About this anime: \n" + synopsis);

                            // Load the poster image asynchronously using the Glide library
                            Glide.with(MainActivity.this)
                                    .load(imageUrl)
                                    .placeholder(android.R.drawable.ic_menu_gallery)
                                    .into(imgAnime);
                        });
                    } else {
                        final int status = conn.getResponseCode();
                        runOnUiThread(() -> Toast.makeText(this, "Server error: " + status, Toast.LENGTH_SHORT).show());
                    }
                } catch (java.io.IOException e) {
                    e.printStackTrace();
                    runOnUiThread(() -> Toast.makeText(this, "Network Error: Check URL or connectivity.", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> Toast.makeText(this, "App Error: Review logcat for details.", Toast.LENGTH_LONG).show());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }).start();
        });
    }
}